let confirm = false;
let updating_php_vars = false;

jQuery('form.checkout').on('checkout_place_order',function() {
    if (jQuery('#payment_method_' + php_vars.id).is(':checked') && !confirm) {
        let swalOptions = {};

        if ('redirect' == php_vars.plugin_payment_mode) {
            swalOptions = {
              html:
                    '<p class="font-13">' +
                        'You will now be redirected to ' + php_vars.short_name + 
                        ' where you can either use your ' + php_vars.short_name + 
                        ' balance or purchase additional ' + php_vars.short_name + 
                        ' to hold and spend.' +
                    '</p>'+
                    '<p class="font-13">' +
                        'If this is your first-time using ' + php_vars.short_name + 
                        ', you will need to create a ' + php_vars.short_name + 
                        ' account to complete this purchase.' +
                    '</p>'+
                    '<p class="pt-1 font-13">Simple checkout with ' + php_vars.short_name + ' </p>',
              showCancelButton: true,
              confirmButtonColor: "#3085D6",
              cancelButtonColor: "#029ed0",
              confirmButtonText: "Yes, Proceed to " + php_vars.short_name,
              cancelButtonText: 'Return to Shopping Cart' ,
              imageUrl: php_vars.plugin_icon,
              imageWidth: 140,
              imageHeight: 35,
              width: "450px"
            };
        }else {
            swalOptions = {
                html: '<h5>You are buying <span class="text-blue">' + php_vars.token_quantity + '</span> ' + php_vars.method_title + '\'s for $' + php_vars.total_amount + '</h5> Yes, use my ' + php_vars.method_title + ' to pay for my purchase of products and/or services from ' + php_vars.vendor_name,
                showCancelButton: true,
                confirmButtonColor: '#3085D6',
                cancelButtonColor: '#4e4e4e',
                confirmButtonText: 'Yes, proceed',
                cancelButtonText: "Cancel Transaction",
                imageUrl: php_vars.plugin_icon,
                imageWidth: 140,
                imageHeight: 35,
                width: "450px"
            }
        }

        Swal.fire(swalOptions).then((result) => {
            if (result.value) {
                confirm = true;
                appendCheckoutType();
                jQuery('form.checkout').submit();
            }
        });
        return false;
    }else{
        return true;
    }
});

/**
 * append checkout type as form field in checkout form
 * 
 * if the element already available set the value
 * else create and append the element to the form
 */
function appendCheckoutType() {
    var input   = document.createElement("input");
    input.type  = "hidden";
    input.name  = "checkout_type";
    input.value = "spends";
    jQuery('form.checkout')[0].appendChild(input);
    return;
}

function applyPostCodeField() {
    setTimeout(() => {
        if (jQuery('#billing_postcode_field').css('display') == 'none' && jQuery('#payment_method_' + php_vars.id).is(':checked')) {
            jQuery('#billing_postcode_field').css('display', 'block');
        }
    }, 300);
}

function get_dg_capital_php_vars() {
    jQuery.get(window.location.origin + '?wc-ajax=get_dg_capital_php_vars', function(data) {
        try {
            php_vars = JSON.parse(data);
            
            let total_el             = jQuery('.order-total >');
            php_vars.total_amount    = parseFloat(parseFloat((total_el.text().replace(/\D+/g, '')) / 100)).toFixed(2);
            php_vars.token_quantity  = ((php_vars.total_amount * 100) / php_vars.gold_price).toFixed(9);
        } catch (error) {
            console.error(error);
        }
    });
}

jQuery("#billing_country").blur(function() {
    applyPostCodeField();
});

jQuery('body').bind('checkout_error', function(){
    /**
     * if checkout has error
     * and the error block have error block
     * get the information and populate as popup
     */
    
    let error_block = jQuery('#' + php_vars.id + '-error-block');
    if (jQuery('#payment_method_' + php_vars.id).is(':checked') && confirm && error_block.length) {

        let url   = error_block.children('#data').data('url');
        let is_register = error_block.children('#data').data('register');
        if (is_register) {
            registerPopup(url)
        } else {
            notEnoughPopup(url)
        }
    }

    confirm = false;
})


function registerPopup(url) {
    let email = (new URL(url) ).searchParams.get("email");

    let swalOptions = {};
    swalOptions = {
        html:(
            '<img class="emoji-sad" src="' + php_vars.images_dir + 'emoji-sad.png"/></br>'+
            '<p class="pt-3 font-13">Oops it appears that '+email+' doesn’t have'+
            ' a '+php_vars.short_name+' account yet. No problem, just register for'+
            ' your very own '+php_vars.short_name+' account by clicking this '+
            '<a href="'+url+'" target="_blank" onclick="swal.close()">Link</a> and completing the account activation process'
        ),
        showCancelButton: false,
        showCloseButton: true,
        confirmButtonColor: "#3085D6",
        cancelButtonColor: "#029ed0",
        confirmButtonText: "Register here "+php_vars.short_name.toUpperCase(),
        cancelButtonText: "Cancel Transaction",
        imageUrl: php_vars.plugin_icon,
        imageWidth: 140,
        imageHeight: 35,
        width: "450px",
        footer: php_vars.app_url_raw
    };

    Swal.fire(swalOptions).then((result) => {
        if (result.value) {
            confirm = true;
            window.open(url, '_blank');
        }
    });
}

function notEnoughPopup(url) {
    let url_object = new URL(url);
    let email      = jQuery('.checkout input[name="billing_email"]').val();
    let name       = jQuery('.checkout input[name="billing_first_name"]').val();
    let content    = (
        '<img class="emoji-sad" src="' + php_vars.images_dir + 'emoji-sad.png"/></br>'+
        '<span class="font-13">' + email +'</span>'+
        '<p class="pt-3 font-13 text-justify">'+ name +', it appears that there are insufficient'+
        ' funds in your '+ php_vars.short_name +' account to complete this purchase. Please follow the link'+
        ' below to log into your '+ php_vars.short_name +' account and top up your balance.  Once you have'+
        ' added '+ php_vars.short_name +' to your account 😊 you can continue on to transfer your '+ php_vars.short_name +
        ' to complete this purchase.</p>'
    );
    let button_text = "LOGIN TO ADD " + php_vars.short_name.toUpperCase();
    if (url_object.pathname.split('/')[1] == 'verify-by-otp') {
        content    = (
            '<span class="font-13">' + email +'</span>'+
            '<p class="pt-3 font-13 text-justify">☹ '+ name +', it appears you don’t currently have a '+ php_vars.short_name +
            ' account under the email '+ email +'. Good news though, once you click on ‘proceed’ below you will be taken'+
            ' to the account activation process, it is quick and easy, once you set up and activate your account, '+
            'you will be able to complete this purchase and use your account for future purchases as well. 😊</p>'
        );
        button_text = "Proceed";
    }

    let swalOptions = {};
    swalOptions = {
        html: content,
        showCancelButton: false,
        showCloseButton: true,
        confirmButtonColor: "#3085D6",
        cancelButtonColor: "#029ed0",
        confirmButtonText: button_text,
        cancelButtonText: "Cancel Transaction",
        imageUrl: php_vars.plugin_icon,
        imageWidth: 140,
        imageHeight: 35,
        width: "450px",
        footer: php_vars.app_url_raw
    };

    Swal.fire(swalOptions).then((result) => {
        if (result.value) {
            confirm = true;
            window.open(url, '_self');
        }
    });
}

jQuery('body').bind('update_checkout', function() {
    if ('redirect' == php_vars.plugin_payment_mode) return;
    
    setTimeout(() => {
        if (!updating_php_vars) {
            updating_php_vars = true;
            get_dg_capital_php_vars();
        }
    }, 2000);
    updating_php_vars = false;
});

jQuery('form.checkout').on('change', 'input[name^="payment_method"], #billing_country', function() {
    jQuery('body').trigger('update_checkout');
});

this.applyPostCodeField();
